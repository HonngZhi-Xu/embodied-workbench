# UR5e 现场流程 v0.2.4

平台作为现有采集程序的外部管理层。原 /home/zaq/gello_software 和 /home/zaq/diffusion_policy 的脚本、设备控制、数据格式、训练代码和校验回执保持原样。平台不注入或替换原程序代码，不改写原 Zarr、运行清单或结果。

## 更新与配置

在 Linux 工位更新本仓库的前端与 edge_agent 后，重启本地服务并刷新浏览器：

```bash
cd /home/zaq/embodied-workbench
git pull --ff-only
python -m edge_agent.server
```

从原有可找到 conda、可显示 OpenCV 本机窗口的终端启动。访问 http://127.0.0.1:8787/#ur5e 并连接本地工作台。线上静态演示不能控制工位硬件。

旧工位配置保留；核对新增的采集模式、接续路径和外部数据根目录后保存。IP、相机序列号、串口只用于记录或独立诊断，不会改写原程序的真实硬件绑定，实际绑定以原配置与运行清单为准。

保留原程序所需的工作目录、Python 环境、PYTHONPATH、DISPLAY 和必要的 XAUTHORITY。平台继承本地服务环境，不自动安装、替换或修补原项目环境。

## 启动与按键

启动前先结束其他终端的采集程序，并断开平台独立相机／触觉诊断，避免重复占用。平台只能控制自己启动的 PTY 会话。核对最终命令与参数快照，明确确认无外部采集占用后启动。

| 模式 | 最终参数 |
| --- | --- |
| 三路 RGB＋触觉（默认） | bash SCRIPT，不追加 --no-tactile |
| 仅三路 RGB | 追加 --no-tactile |
| 接续已有数据 | 对应模式追加 --resume PATH |

SCRIPT 默认 /home/zaq/gello_software/experiments/start_live_follow_local.sh。参数通过 argv 数组启动，不使用 shell 拼接执行路径。接续路径需存在且模式兼容，原脚本拥有最终决定权。

| 操作 | 发送内容 | 前置状态 |
| --- | --- | --- |
| 确认现场准备，继续启动 | Enter | 实际 Bash 启动确认提示 |
| 确认姿态并执行对齐 | ALIGN＋Enter | 实际 ALIGN 输入提示，明确确认 |
| 确认对齐已完成 | 仅平台确认 | 已收到 alignment_completed，再由操作员核对 |
| 开始本条／开始下一条 | s＋Enter | 持续跟随、未录制 |
| 保存本条 | Enter | 录制中 |
| 丢弃当前条 | d＋Enter | 录制中，单独确认 |
| 删除最近已保存的一条 | u＋Enter | 未录制，单独确认 |
| 保存当前有效片段并退出 | q＋Enter | 已进入采集主循环 |

每条都通过 s 开始，u 绝不是下一条。保存或丢弃后仍可能持续遥操跟随，不表示机械臂停止。短片段、质量不达标或故障片段可能被原脚本拒绝保存。

启动确认、ALIGN 和对齐完成都不自动确认。说明中的 ALIGN 不启用对齐按钮。适配器处理提示分块、无换行和多提示情况；对齐拒绝并重新提示时可再次确认。无法识别时保守显示未知／等待确认。

未知现场提示可在平台数据目录 capture-prompts.json 配置 startup/align 字面完整提示，先核对原终端输出；这只改变平台的识别规则，不改原项目、不自动发送按键。

## 退出、状态与会话

q 后等待原程序保存、设备清理、退出与结果；不承诺所有当前片段一定保存成功。

另设中断采集进程。SIGINT、SIGTERM 和 SIGKILL 需要明确区分并单独确认，等待超时不会自动升级强杀。中断可能丢弃未保存片段，之前数据仍需核对；软件进程操作不是硬件急停。

终端线程只接收 PTY 输出，日志和结果在平台侧独立读取。利用 capture.jsonl、run_manifest.json、result.json、dataset_manifest.json 辅助识别：

- 命令已发送与已实际执行分开。
- episode_finished 的 queued=true 只表示进入保存队列，不是落盘完成。
- 缺回执、too_short、时序质量失败、传感器中断和写盘错误不展示为保存成功。
- 正常退出结合最终结果与数据检查，不仅凭返回码判断有效。
- 浏览器刷新和多个页面复用会话，控制请求带 session_id/request_id，旧会话不可控制新会话，同一请求不重复删除。
- 后端重启不能恢复原 PTY，存活但无控制通道的进程只读显示，不宣称已接管。
- 关闭平台服务不将 q 保存退出替换成自动终止原采集进程。

## 数据登记、回放与训练

外部根目录默认 /home/zaq/runtime_logs/live_follow_capture，可在工位设置修改。数据页扫描历史或登记真实 Zarr 路径，资产索引保存在平台自己的数据目录，原始数据不搬动、不改写。

资产 ID 用于检查、缩略图、回放和训练解析，路径必须位于配置范围内，拒绝目录越界和符号链接逃逸。采集中只展示轻量状态，不全量扫描变化中的数据。退出写盘后，操作员执行完整检查。

检查包括结构、物理数据块、完整标志 episode_operator_complete、结束原因 episode_end_reason_code、时序质量和最终保存结果。活跃、未检查、不完整或未知数据不允许默认训练。production_training_qualified=false 或 operator_confirmation_pending=true 也会阻止训练。平台不会静默删除不完整片段；筛选需明确派生数据或规则。

训练使用已登记且通过检查的真实绝对路径。原视觉 DP 预设仍是 train_gello_live_image_20hz、三路 RGB＋robot_joint＋gripper_position，删除 tactile 观测，resume=false。含触觉采集不意味着视觉预设已使用触觉训练。平台请求快照和进程日志写在平台数据目录，训练程序按原方式产生模型输出。

## 画面与验证边界

实时画面继续由原程序 OpenCV 本机窗口提供。仅设置 EMBODIED_EDGE_URL 不会让该入口自动推送网页图像。采集时禁止再次独立打开相机或触觉串口。网页缩略图和限量回放来自已保存数据，不是实时流，不能作为相机标定原始输入。

自动验证只用平台自有模拟交互、合成日志和临时 Zarr，不运行真机采集脚本。Windows 可运行界面与离线检查，真实 PTY 和桌面预览需 Linux 工位验收。本次未连接 /home/zaq，现场提示文字和硬件行为仍需核对。
